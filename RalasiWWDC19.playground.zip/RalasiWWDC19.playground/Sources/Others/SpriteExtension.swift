import Foundation
import SpriteKit


extension ReduceWasteage : FoodNodeDelegate{
    
    //Handles when user clicks on the Emoji and adds an Animation.
    func didTap(sender: FoodNode) {
        let value = Int(sender.name ?? "0")
        scoreValue = scoreValue + (value ?? 0)
        self.mark.text = "Score : \(scoreValue)"
        
        if value! > 0
        {
            let namaste = SKLabelNode(fontNamed: "Helvetica Neue")
            namaste.text = "+\(value!)"
            namaste.name = initialTextNodes
            
            namaste.fontSize = 15
            namaste.fontColor = SKColor.blue
            namaste.position = CGPoint(x: sender.position.x, y: sender.position.y)
            addChild(namaste)
            
            var fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            namaste.run(fadeOutAction, completion: {
                namaste.removeFromParent()
            })
            var eat = "😲"
            let emoji2 = SKLabelNode(fontNamed: "Helvetica Neue")
            emoji2.text = eat
            emoji2.fontSize = 20
            emoji2.fontColor = SKColor.black
            emoji2.position = CGPoint(x: sender.position.x, y: sender.position.y + 20)
            addChild(emoji2)
            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            emoji2.run(fadeOutAction, completion: {
                emoji2.removeFromParent()
            })
            
            let emoji3 = SKLabelNode(fontNamed: "Helvetica Neue")
            emoji3.text = eat
            emoji3.name = initialTextNodes
            emoji3.fontSize = 20
            emoji3.fontColor = SKColor.black
            emoji3.position = CGPoint(x: sender.position.x - 20, y: sender.position.y)
            addChild(emoji3)
            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            emoji3.run(fadeOutAction, completion: {
                emoji3.removeFromParent()
            })
            
        }
        else if value! < 0
        {
            let namaste = SKLabelNode(fontNamed: "Helvetica Neue")
            namaste.text = "\(value!)"
            namaste.name = initialTextNodes
            namaste.fontSize = 15
            namaste.fontColor = SKColor.red
            namaste.position = CGPoint(x: sender.position.x, y: sender.position.y)
            addChild(namaste)
            
            
            var fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            namaste.run(fadeOutAction, completion: {
                
                namaste.removeFromParent()
            })
            
          
            
            let emoji2 = SKLabelNode(fontNamed: "Helvetica Neue")
            emoji2.text = heatEmoji
            emoji2.name = initialTextNodes
            emoji2.fontSize = 20
            emoji2.fontColor = SKColor.black
            emoji2.position = CGPoint(x: sender.position.x, y: sender.position.y + 20)
            addChild(emoji2)
            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            emoji2.run(fadeOutAction, completion: {
                emoji2.removeFromParent()
            })
            
            let emoji3 = SKLabelNode(fontNamed: "Helvetica Neue")
            emoji3.text = heatEmoji
            emoji3.name = initialTextNodes
            emoji3.fontSize = 20
            emoji3.fontColor = SKColor.black
            emoji3.position = CGPoint(x: sender.position.x - 20, y: sender.position.y)
            addChild(emoji3)
            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
            fadeOutAction.timingMode = .easeInEaseOut
            emoji3.run(fadeOutAction, completion: {
                emoji3.removeFromParent()
            })
            
        }
        
        let fadeOutActions = SKAction.fadeOut(withDuration: 0.05)
        fadeOutActions.timingMode = .easeInEaseOut
        sender.run(fadeOutActions, completion: {
            sender.removeFromParent()
            self.addEmojiOnRandomPlaces()
        })
    }
    
}

