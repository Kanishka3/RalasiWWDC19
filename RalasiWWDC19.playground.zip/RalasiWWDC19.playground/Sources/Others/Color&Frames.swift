import Foundation
import UIKit

public  var color =  UIColor(white:0.1, alpha: 1)
public var mainFrame = CGRect(x: 0, y: 0, width: 810, height: 580)
public var stepSize = CGSize(width: 338, height: 235.36)
 
