import Foundation
import UIKit

public  var color =  UIColor(white:0.1, alpha: 1)
public var mainFrame = CGRect(x: 0, y: 0, width: 810, height: 580)
public var stepSize = CGSize(width: 338, height: 235.36)

public var ruleString = "Rounds: \n \n \n Round 1 : Feeding a crying baby \n \n  Round 2: Answer some question testing your general \n \n \n Hope you do great!!"

public var inqu : String = "Hint: If the case you are unsure, click any of the option and the incorrect options will be eleminated"

public var inque : String = "Hint: If the case you are unsure, click any of the option and the incorrect options will be eleminated. Use your intuition"

