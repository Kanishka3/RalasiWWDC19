import Foundation
import UIKit
import PlaygroundSupport



public class Round2Q1 : UIView{
    
    
    var image = UIImageView(image: UIImage(named:"bg.png"))
    var answer = UIView()
    
    var backButton = UIButton()
    
    
    var option1frame = CGRect(x:20,y:325,width:220,height:60)
    var option2frame = CGRect(x: 295, y: 325, width: 220, height: 60)
    var option3frame = CGRect(x: 528, y: 325, width: 220, height: 60)
    
    var instruction = UILabel()
    var round = UILabel()
    var questionLabel = UILabel()
    //declaring initial viiew
    var view1  = UIView()
    var ansView1 = UIButton()
    var ansView2 = UIButton()
    var ansView3 = UIButton()
    //non ususual
    var q = 0
    //option 1
    var option1I = UIImage(named:"sweden.png")
    var option2I = UIImage(named:"Yemen.png")
    var option3I = UIImage(named: "alaska.png")
    
     var roundNo : Int = 1
    
    //stirng
    var q1 = "Which is a country with major food crisis?"
    var instrumentString = inqu
    public override init(frame: CGRect){
        super.init(frame:mainFrame)
      
        ansView1.setImage(option1I, for: .normal)
        ansView1.frame = option1frame
        
        ansView2.setImage(option2I, for: .normal)
        ansView2.frame = option2frame
        
        ansView3.setImage(option3I, for: .normal)
        ansView3.frame = option3frame
        
        image.frame = mainFrame
        image.contentMode = .scaleAspectFill
        
        instruction.frame = CGRect(x:60,y:460,width:680,height:45)
        instruction.text = instrumentString
        instruction.numberOfLines = -1
        backButton.BackButton()
        backButton.addTarget(self, action: #selector(takesYouBack), for: .touchUpInside)
        self.addSubview(backButton)
        self.addSubview(image)
        self.addSubview(instruction)
        
        view1.layer.borderColor = UIColor.black.cgColor
        view1.layer.borderWidth = 12
        view1.layer.cornerRadius = 28
         view1.addSubview(questionLabel)
        self.addSubview(view1)
        
     
        questionLabel.text = q1
        questionLabel.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        questionLabel.frame = CGRect(x:15,y:15,width:480, height:135)
        view1.frame = CGRect(x:60,y:60,width:600,height: 120)
        
        var array = [ansView1, ansView2, ansView3]
        
        for i in array {
            i.isUserInteractionEnabled = true
            self.addSubview(i)
            i.layer.cornerRadius = 9
           
        }
        
        ansView1.tag = 0
        ansView2.tag = 1
        ansView3.tag = 0
//
        answer.frame = CGRect(x:235,y:195,width:330,height:70)
        answer.layer.borderWidth = 6
        answer.layer.borderColor = UIColor.green.cgColor
        answer.layer.cornerRadius = 15
        self.addSubview(answer)
        
        ansView1.addTarget(self, action: #selector(func1), for: .touchUpInside)
        ansView3.addTarget(self, action: #selector(func1), for: .touchUpInside)
        
         ansView2.addTarget(self, action: #selector(func2), for: .touchUpInside)
        
    }
    
    
    @objc func takesYouBack(){
        self.removeFromSuperview()
        var Menu = SmallChanges(frame: mainFrame)
        PlaygroundPage.current.liveView = Menu
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func func1(){
        UIView.animate(withDuration: 4, delay: 1, usingSpringWithDamping: 2, initialSpringVelocity: 2, options: UIView.AnimationOptions.curveLinear, animations: {
            self.ansView1.center.y = self.ansView1.center.y + 300
        }, completion: nil)
        
            UIView.animate(withDuration: 4, delay: 1, usingSpringWithDamping: 2, initialSpringVelocity: 2, options: UIView.AnimationOptions.curveLinear, animations: {
                self.ansView3.center.y = self.ansView3.center.y + 300
            }, completion: nil)

        }
     

    
    @objc func func2(){
        UIView.animate(withDuration: 1, delay: 0.5, options: UIView.AnimationOptions.curveLinear, animations: {
            self.ansView2.alpha = 0.5
        }) { (true) in
            self.answer.addSubview(self.ansView2)
            self.ansView2.frame = CGRect(x:20,y:6,width:self.option2frame.width,height:self.option2frame.height)
            self.ansView2.alpha = 1
            Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.NextQ), userInfo: nil, repeats: false)
        }
    }
    
    
    @objc func NextQ(){
        self.removeFromSuperview()
        var nextQ = Round2Q2(frame: mainFrame)
        PlaygroundPage.current.liveView = nextQ
    }
 
}
    

