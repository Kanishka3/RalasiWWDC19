import Foundation
import PlaygroundSupport
import  UIKit

public class SocialServer: UIView{
    
    
    var nextB = UIButton()
    
    
    var name1 = UIButton()
    var name2 = UIButton()
    
    var background = UIImageView()
    
    var person = UILabel()
    
    var saying = UILabel()
    var sayaView = UIView()
    
    var backB = UIButton()
    
    var string1 = "Superman Right to Food 7"
    var string2 = "Earth Food Avenger 21"
    
    var string3 = "Imperfect grocery products"
    var string4 = "Leftovers from restaurants"
    var que = "What would you like to name your NGO for food service that you are starting here (at WWDC)?"
    var que2 = "Where would you like to start delivering this food?"
    var que3 = "What would you like to serve to malnourished people?"
    var congo = "🤩 CONGRATULATIONS for your FIRST NGO!! I like you move it great!!😎"
    var rew = "As you have help me rescue the world, its time to get some reward"
    
    
    public override init(frame: CGRect) {
        super.init(frame: mainFrame)
        
        self.addingBackground()
        print("You have entered \"Social Server \" view")
        //adding back button
        backB.BackButton()
        backB.addTarget(self, action: #selector(takesYouBack), for: .touchUpInside)
        self.addSubview(backB)
        
        Timer.scheduledTimer(timeInterval:1, target: self, selector: #selector(addingPerson), userInfo: nil, repeats: false)
        

    }
    
    @objc func addingPerson(){
        
        person.LabelSimplified(text: "💁‍♀️", size: 155, weight: .bold, frame: CGRect(x:295,y:315,width:180,height:110), alignment:.justified )
        
        self.addSubview(person)
        
        Timer.scheduledTimer(timeInterval:1, target: self, selector: #selector(addingQuestion), userInfo: nil, repeats: false)
        
        
        
    }
    
    
    func addingBackground(){
        
        background.ImageSimplified(named: "road.png", contentMode: .scaleAspectFit, frame: mainFrame, cornerRadius: 3)
        
        
        
        self.addSubview(background)
        
    }
    
    @objc func addingOption(){
        
        name1.buttonSimplified(color: .red, textColor: .white, text: string1, frame: CGRect(x:40,y:235,width:220,height:56), textSize: 16)
        
        name2.buttonSimplified(color: .blue, textColor: .white, text: string2, frame: CGRect(x:380,y:235,width:220,height:56), textSize: 16)
        
        self.addSubview(name2)
        self.addSubview(name1)
        
        name1.addTarget(self, action: #selector(avenger21), for: .touchUpInside)
        name2.addTarget(self, action: #selector(avenger21), for: .touchUpInside)
    }
    
    
    @objc func addingQuestion(){
        
        sayaView.ViewSimplified(frame: CGRect(x:130,y:65,width:207,height:140), cornerRadius: 30, backgroundColor: .white)
        
        
        saying.LabelSimplified(text: que, size: 18, weight: .regular, frame: CGRect(x:7,y:3,width:186,height:172), alignment: .center)
        saying.TypeWriter(typedText: que, characterDelay: 0.01)
        self.addSubview(sayaView)
        sayaView.addSubview(saying)
        
        Timer.scheduledTimer(timeInterval:2, target: self, selector: #selector(addingOption), userInfo: nil, repeats: false)
        
        
    }
    
    @objc func avenger21(){
        name1.setTitle("African countries", for: .normal)
        name2.setTitle("Asian Countries", for: .normal)
        saying.text = que2
        
        name1.addTarget(self, action: #selector(anotherQue), for: .touchUpInside)
        name2.addTarget(self, action: #selector(anotherQue), for: .touchUpInside)
    }
    
    
    
    @objc func anotherQue(){
        saying.TypeWriter(typedText: que3)
        name1.setTitle(string3, for: .normal)
        name2.setTitle(string4, for: .normal)
        
        name1.addTarget(self, action: #selector(congra), for: .touchUpInside)
        name2.addTarget(self, action: #selector(congra), for: .touchUpInside)
      
    }
    
    @objc func congra(){
        name1.removeFromSuperview()
        name2.removeFromSuperview()
        
         saying.text = congo
        Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(nextThing), userInfo: nil, repeats: false)
    }
    
    @objc func nextThing(){
        person.removeFromSuperview()
        sayaView.removeFromSuperview()
       
        var bold = UILabel()
        bold.textColor = .white
        bold.BoldyMen(text: rew, size: 25)
        self.addSubview(bold)
        bold.frame = CGRect(x: 40, y: 59, width: 700, height: 380)
         nextB.buttonSimplified(color: .red, textColor: .white, text: "Next >", frame: CGRect(x:245,y:403,width:293,height:80), textSize: 25)
        self.addSubview(nextB)
        nextB.addTarget(self, action: #selector(reward), for: .touchUpInside)
    }
    
    @objc func reward(){
         self.removeFromSuperview()
        var rewardV = Reward(frame: mainFrame)
        PlaygroundPage.current.liveView = rewardV
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @objc func takesYouBack(){
        self.removeFromSuperview()
        var Menu = SmallChanges(frame: mainFrame)
        PlaygroundPage.current.liveView = Menu
    }

    
   
}


