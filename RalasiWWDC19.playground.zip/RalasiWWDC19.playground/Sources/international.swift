import Foundation
import UIKit
import PlaygroundSupport
import SpriteKit



class ReducingInternationalDemand: SKScene{
    
    
    override func didMove(to view: SKView) {
        
        
    
    }
    
      
}
