import Foundation
import UIKit
import PlaygroundSupport
import SpriteKit
public class SmallChanges : UIView{
    
    
    
    
    var step1 = UIButton()
    
    
    var step2 = UIButton()
    
    
    var step3 = UIButton()
    
    var step4 = UIButton() //my fav step so far
    
    
    
    
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //basically viewDidLoad() of UIViewController()
    override public init(frame: CGRect){
        super.init(frame:mainFrame)
        simpleSteps()
        self.backgroundColor = .white
    }
    func simpleSteps(){
        
        
        step1.ImageButton(image: "Step1.png", cornerRadius: 6, frame: CGRect(x:18,y:25,width:stepSize.width,height: stepSize.height))
        
        step2.ImageButton(image: "step2.png",cornerRadius: 6, frame: CGRect(x:425,y:20.3,width:stepSize.width,height:stepSize.height))
        
        step3.ImageButton(image: "step3.png",  cornerRadius: 6, frame: CGRect(x:18,y:315,width:stepSize.width,height:stepSize.height))
        
        step4.ImageButton(image: "step4.png",cornerRadius: 6, frame: CGRect(x:425,y:317,width:stepSize.width,height:stepSize.height))
        
        step4.addTarget(self, action: #selector(GoToReward), for: .touchUpInside)
        step1.addTarget(self, action: #selector(goToFoodWastage), for: .touchUpInside)
        step3.addTarget(self, action: #selector(GoToSocialServer), for: .touchUpInside)
        
        self.addSubview(step2)
        self.addSubview(step3)
        self.addSubview(step4)
        self.addSubview(step1)
    }
    
    
    
    func AddConfetti(){
        let confetti = SAConfettiView(frame: self.bounds)
        confetti.type = SAConfettiView.ConfettiType.star
        confetti.colors = [.red, .blue, .green, .yellow]
        confetti.intensity = 5
        self.addSubview(confetti)
    }
    
    @objc func GoToReward(){
        self.removeFromSuperview()
        print("The Program is Executed")
        var view =  Reward(frame: mainFrame)
        PlaygroundPage.current.liveView = view
    }
    
   // time to call and override some delegate functions
        public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      
            if let touches = touches.first  {
                
                
            }
        }
    
    @objc func GoToSocialServer(){
       var view = SocialServer(frame: mainFrame)
        PlaygroundPage.current.liveView = view
    }
    
    
    @objc func goToFoodWastage(){
        var view = SKView(frame: mainFrame)
        var scene = ReduceWasteage(size: CGSize(width: mainFrame.width, height: mainFrame.height))
        view.presentScene(scene)
        PlaygroundPage.current.liveView = view
        
    }
    
    
    @objc func GoToReduceInternational(){
        
    }
    
    
    
    
    
    
}


