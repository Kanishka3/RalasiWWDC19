import Foundation
import UIKit
import PlaygroundSupport
import SpriteKit

public class ReWaRu : UIView {
    
    var background = UIImageView()
    var button = UIButton()
    var rules = UILabel()
    var ba = UIButton()
    
    
    public override init(frame: CGRect) {
        super.init(frame:mainFrame)
        
        rules.LabelSimplified(text: ruleString, size: 24, weight: .medium, frame: CGRect(x:30,y:35,width:700,height:520), alignment: .center)
        
        ba.BackButton()
        ba.addTarget(self, action: #selector(takesYouBack), for: .touchUpInside)
        background.image = UIImage(named:"bg.png")
        background.frame = mainFrame
        button.setImage(UIImage(named:"Play.png"), for: .normal)
        button.frame = CGRect(x:670,y:540,width:85,height:32)
//        button.setImage(UIImage("Play.png"), for: .normal)
        self.addSubview(background)
        self.addSubview(rules)
        self.addSubview(button)
        self.addSubview(ba)
        button.addTarget(self, action: #selector(goToGame), for: .touchUpInside)
        
    }
    
    
    
    @objc func goToGame(){
       
        UIView.animate(withDuration: 1, delay: 0.5, usingSpringWithDamping: 3, initialSpringVelocity: 5, options: UIView.AnimationOptions.curveLinear, animations: {
            self.rules.alpha = 0.5
        }) { (true) in
            self.removeFromSuperview()
        }
        var scene = Round1(frame: mainFrame)
        
        PlaygroundPage.current.liveView = scene
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func takesYouBack(){
        self.removeFromSuperview()
        var Menu = SmallChanges(frame: mainFrame)
        PlaygroundPage.current.liveView = Menu
    }
    
   
}
