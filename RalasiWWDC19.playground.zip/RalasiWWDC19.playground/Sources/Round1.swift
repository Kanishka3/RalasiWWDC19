import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

public class Round1 : UIView{
    var background = UIImageView()
    var baby = UILabel()
    
    var person = UILabel()
    
    var move = UIButton()
    
    var instruction = "The child is hungry, feed him..."
    
    var player = AVAudioPlayer()
    
    var saying = UILabel()
    var sayaView = UIView()
    
    var tacho = UILabel()
    
    var b2 = UIButton()
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    public override init(frame: CGRect) {
        super.init(frame:mainFrame)
        
        self.BabySound()
        background.image = UIImage(named:"ground.jpg")
        background.contentMode = .scaleAspectFill
        background.frame = mainFrame
        baby.text = "👶🏼"
        person.text = "🚶🏻‍♂️"
        tacho.text = "🌮"
        
        baby.font = UIFont.boldSystemFont(ofSize:49)
        person.font = UIFont.boldSystemFont(ofSize: 67)
        tacho.font = UIFont.boldSystemFont(ofSize: 35)
        
        person.frame = CGRect(x:635,y:400,width:50,height:120)
        baby.frame = CGRect(x:132,y:400,width:77,height:89)
        tacho.frame = CGRect(x: 132,y:170,width:20,height:20)
        
        move.buttonSimplified(color: .red, textColor: .white, text: "Go to him", frame: CGRect(x:650,y:540,width:110,height:32), textSize: 17)
        
    b2.buttonSimplified(color: .green, textColor: .black, text: "Offer him tacho", frame: CGRect(x:630,y:540,width:140,height:35), textSize: 17)
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(moveButton), userInfo: self, repeats: false)
//        move.addTarget(self, action: #selector(moveButton), for: .touchUpInside)
        self.addSubview(background)
        self.addSubview(baby)
        self.addSubview(person)
       
        BabySound()
    }
     
    
    @objc func moveButton(){
        self.addSubview(move)
        
        
        sayaView.ViewSimplified(frame: CGRect(x:130,y:65,width:207,height:140), cornerRadius: 30, backgroundColor: .white)
        
        
        saying.LabelSimplified(text: instruction, size: 18, weight: .regular, frame: CGRect(x:7,y:3,width:186,height:172), alignment: .center)
        saying.TypeWriter(typedText: instruction)
        self.addSubview(sayaView)
        sayaView.addSubview(saying)
        
        Timer.scheduledTimer(timeInterval: 4, target: self, selector: #selector(mainFunc), userInfo: nil, repeats: false)
        
    }
    
    @objc func mainFunc(){
        sayaView.removeFromSuperview()
        self.addSubview(move)
        move.addTarget(self, action: #selector(moveStraight), for: .touchUpInside)
        
    }
    
    
    @objc func moveStraight(){
    
        move.removeFromSuperview()
        UIView.animate(withDuration: 4, delay: 1, usingSpringWithDamping: 2, initialSpringVelocity: 3, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.person.center.x =  self.person.center.x - 480
        }) { (true) in
               self.moveLeft()
        }
    }
    
    @objc func moveLeft(){
        saying.text = "Offer him tacho"
        self.addSubview(sayaView)
//        move.setTitle("Offer him 🌮", for: .normal)
        b2.addTarget(self, action: #selector(taco), for: .touchUpInside)
        self.addSubview(b2)
        
    }
    
    @objc func taco(){
        sayaView.removeFromSuperview()
        
         self.addSubview(tacho)
        b2.removeFromSuperview()
        Timer.scheduledTimer(timeInterval: 2.1, target: self, selector: #selector(os), userInfo: nil, repeats: false)
        
    }
    
    
    @objc func nextRound(){
        self.removeFromSuperview()
        var view = Round2Q1(frame: mainFrame)
        PlaygroundPage.current.liveView = view
    }
    
    @objc func os(){
    self.addSubview(sayaView)
    self.saying.text = "your rescued the child.. You are awesome. Time of next round"
    self.move.setTitle("Next Round", for: .normal)
    self.move.addTarget(self, action: #selector(nextRound), for: .touchUpInside)
        self.addSubview(move)
    }
    
    @objc func BabySound() {
        
        let path = Bundle.main.path(forResource: "babecry", ofType : "mp3")!
        let url = URL(fileURLWithPath : path)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player.play()
            
        } catch {
            
            print ("There is an issue with this code!")
            
        }
    
        
    }

    
}
