import UIKit
import PlaygroundSupport
var str = "Hello, WWDC"


//: # Solving World Problems

//:  Even in this modern world where Elon Musk is imagining the future of humanity on Mars, there are the fundamental problems *(like education, water problems, poverty, starvation)* which are not solved yet. SO, let's solve some in today's WWDC playground.


//:  ## Food crisis and food waste

//: Still about 18.2% people on the earth are hungry. The basic problems of world aren't solved. [1](https://www.inc.com/business-insider/worlds-top-10-problems-according-millennials-world-economic-forum-global-shapers-survey-2017.html)

//: Still today about **1/10** person goes to bed being hungry 😮
//:  Still, **800 million** people are hungry today. [2](https://www.youtube.com/watch?v=QJG7HmQyYcY)

//: Most of the world's population live in countries where overweight and obesity kills more people than underweight

//:[Source : WHO](https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight)

//: One side their are this people obesed and on other side there are people who can never gave enough food to let their body grow

//: ![Man suffering with obesity](obe.png)

//: ![Childrens suffering with malnutrition](mal.jpeg)



//: ## How did we solved that in this playground?

//: Here, we will solve that problem in a "Choose your adventure" 2D game.


//: But we bring **BIG CHANGES** by taking **SMALL STEPS**

//: **Step 1** : Food Fun round - Time of have some rounds

//: **Step 2** : 7 question quizlet - Reduce the wastage of food in daily life and thus reduce the demand of food in international market (and thus reduce the price of grains and vegetable in international market and *preventing the price rise*)

//: **Step 3** : Starting an NGO of your own choice

//: **Step 4** : 🎊 Reward time


//: #### START SMALL, DO BIG





var view = wholeView(frame: mainFrame)
PlaygroundPage.current.liveView = view

