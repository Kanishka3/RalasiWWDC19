import Foundation
import PlaygroundSupport
import UIKit

/*
 Aim of this class:
 1) Create some message to be shown based on Scheduled Timer
 
 */
public class BlinkText: UIView {
    
    //declaring variables
    
    var label = UILabel()
    var button = UIButton()
    
    var text1 = "There are lot of fundamental problems in "
    var text2 = "the 🌏 that are yet not solved"
    var text3 = "So, let’s solve some in today’s playground 🧗🏼‍♀️"
    
    
    override public init(frame: CGRect) {
        super.init(frame: mainFrame)
        
        self.backgroundColor = .white
        button.buttonSimplified(color: .red, textColor: .white, text: "Let's go", frame: CGRect(x: 245, y: 403, width: 290, height: 80), textSize: 30)
       
        label.frame = CGRect(x: 40, y: 59, width: 700, height: 380)
        label.BoldyMen(text: text1, size: 49)

        button.addTarget(self, action:"next", for: .touchUpInside)
        
     self.problems()
    }
    
    
    func problems(){
        self.addSubview(label)
        
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(world), userInfo: nil, repeats: false)
    }
    
    @objc func world(){
        label.BoldyMen(text: text2, size: 49)
        
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(solved), userInfo: nil, repeats: false)
    }
    
    @objc func solved(){
        label.BoldyMen(text: text3, size: 49)
        Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(buttonAdded), userInfo: nil, repeats: false)
    }
    
    @objc func buttonAdded(){
    self.addSubview(button)
    }
  
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    @objc public func next(){
        self.removeFromSuperview()
       PlaygroundPage.current.liveView = GoalChecker(frame: mainFrame)
        
    }
    
}
