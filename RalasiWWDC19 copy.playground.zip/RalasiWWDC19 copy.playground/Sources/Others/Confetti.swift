
//
//  Confetti.swift
//  ConfettiTEST
//
//  Created by James Tuttle on 7/15/16.
//  Copyright © 2016 James Tuttle. All rights reserved.
//
//
//  ViewController.swift
//  ConfettiTEST
//
//  Created by James Tuttle on 7/15/16.
//  Copyright © 2016 James Tuttle. All rights reserved.
//
import SpriteKit


class Confetti: SKScene, SKPhysicsContactDelegate {
    
    
    
    let emitter = SKEmitterNode(fileNamed: "maincon")
    let colors = [SKColor.red,SKColor.blue ,SKColor.green,SKColor.black]
    
    
    override func didMove(to view: SKView) {
        
        
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        
        emitter?.position = CGPoint(x: 200, y:300)
        
        emitter?.particleColorSequence = nil
        emitter?.particleColorBlendFactor = 1.0
        
        self.addChild(emitter!)
        
        let action = SKAction.run({
            [unowned self] in
            let random = Int(arc4random_uniform(UInt32(self.colors.count)))
            
            self.emitter?.particleColor = self.colors[random];
            print(random)
        })
        
        let wait = SKAction.wait(forDuration: 0.1)
        
        self.run(SKAction.repeatForever( SKAction.sequence([action,wait])))
        
        
    }
    
}
