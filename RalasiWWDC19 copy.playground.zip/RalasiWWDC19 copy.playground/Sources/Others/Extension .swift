import Foundation
import UIKit

// Here an extension of UILabel is taken from the answer of https://stackoverflow.com/users/4196475/dimas-mendes
// the TypeWriter function of UILabel is taken from the answer of Dimas Mendes

extension UIButton {
    
    
    public func buttonSimplified(color: UIColor, textColor: UIColor, text:String, frame: CGRect, textSize: CGFloat){
        
    self.backgroundColor = color
    self.setTitleColor(textColor, for: .normal)
    self.setTitle(text, for: .normal)
    self.frame = frame
    self.titleLabel?.font = UIFont.systemFont(ofSize: textSize)
    self.layer.cornerRadius = 4
        
    }
    
    public func fortified(color: UIColor, size: CGFloat){
        
        self.layer.borderColor = color.cgColor
        self.layer.borderWidth = size
    }
    
    public func ImageButton(image: String, cornerRadius: CGFloat, frame: CGRect){
        
        self.setImage(UIImage(named:image), for: .normal)
        self.layer.cornerRadius = cornerRadius
        self.frame = frame
        
    }
    
    
}

extension UILabel{
    
    public func BoldyMen(text: String, size: CGFloat){
       
        self.font = UIFont.systemFont(ofSize: size, weight: UIFont.Weight.bold)
        self.text = text
        self.numberOfLines = -1
        self.textAlignment = NSTextAlignment.center
        
        
    }
    
    
    
    public func LabelSimplified(text: String, size: CGFloat, weight: UIFont.Weight, frame: CGRect, alignment: NSTextAlignment){
        
        self.text = text
        self.textAlignment = alignment
        self.frame = frame
        self.font = UIFont.systemFont(ofSize: size, weight: weight)
        self.numberOfLines = -1
    }
    
   
        public func TypeWriter(typedText: String, characterDelay: TimeInterval = 5.0) {
            text = ""
            var writingTask: DispatchWorkItem?
            writingTask = DispatchWorkItem { [weak weakSelf = self] in
                for character in typedText {
                    DispatchQueue.main.async {
                        weakSelf?.text!.append(character)
                    }
                    Thread.sleep(forTimeInterval: characterDelay/100)
                }
            }
            
            if let task = writingTask {
                let queue = DispatchQueue(label: "typespeed", qos: DispatchQoS.userInteractive)
                queue.asyncAfter(deadline: .now() + 0.05, execute: task)
            }
        }
    
}


extension UIImageView{
    
    public func ImageSimplified(named: String, contentMode: UIImageView.ContentMode, frame: CGRect, cornerRadius: CGFloat){
        self.image = UIImage(named: named)
        self.contentMode = contentMode
        self.frame = frame
        self.layer.cornerRadius = cornerRadius
        
    }
}

extension UIView{
    
    public func shakeitoff(duration: CFTimeInterval, repeatC: Float, change: CGFloat){
        
            let animation = CABasicAnimation(keyPath: "shakeitoff")
            animation.duration = duration
            animation.repeatCount = repeatC
            animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - change, y: self.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + change, y: self.center.y))

            self.layer.add(animation, forKey: "shakeitoff")

    }
    
   ///To add a gradient layer to the view
    public func addGradientLayer(colors: [CGColor]){
        
        var gradient : CAGradientLayer!
        gradient = CAGradientLayer()
        gradient.colors = colors
        gradient.frame = self.frame
        self.layer.addSublayer(gradient)
    }
    
    public func ViewSimplified(frame: CGRect, cornerRadius:CGFloat,backgroundColor:UIColor){
        
        self.frame = frame
        self.layer.cornerRadius = cornerRadius
        self.backgroundColor = backgroundColor
        
        
    }
}
