import Foundation
import PlaygroundSupport
import  AVFoundation
import UIKit

/*
 Aim of this class:
 1) Adding a small image of creator
 2) Adding a big thankyou message
 3) Adding a small note about creator
 
 */

public class LastClass : UIView {
    
    let upperView = UIView()
    let bottomView = UIView()
    
    let image = UIImageView()
    
    let upperLabel = UILabel()
    let bottomLabel = UILabel()

    
    let upperString = "I hope you enjoyed the playground! Meet you in WWDC and thanks for helping to rescue the 🌏…"
    let lowerString = "Hey there 👋🏼!  I am Kanishka from 🇮🇳 And I love Swift !!"
    
    
    override public init(frame: CGRect) {
        super.init(frame: mainFrame)
        
        self.ModifyingView1()
        self.modifyingView2()
    }
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func ModifyingView1(){
    
        upperView.frame = CGRect(x:0,y:0,width:810, height:320)
        upperView.backgroundColor = .black
        upperLabel.BoldyMen(text: upperString, size: 45)
        upperLabel.textColor = .white
        upperLabel.frame = CGRect(x: 71, y: 49, width: 668, height: 247)
        upperView.addSubview(upperLabel)
        
        self.addSubview(upperView)
    }
    
    func modifyingView2(){
        
        bottomView.frame = CGRect(x:0,y:320, width: 810, height:320)
        self.backgroundColor = .white
        
        bottomLabel.LabelSimplified(text: lowerString, size: 28, weight: UIFont.Weight.medium, frame: CGRect(x: 20, y: 15, width: 521, height: 200), alignment: NSTextAlignment.center)
        
        bottomView.addSubview(bottomLabel)
        
        image.ImageSimplified(named: "me.jpeg", contentMode: .scaleAspectFit, frame: CGRect(x: 550, y: 30, width: 205, height: 220), cornerRadius: 42)
        
        bottomLabel.addSubview(image)
        bottomView.addSubview(bottomLabel)
        self.addSubview(bottomView)
    }
    
}
