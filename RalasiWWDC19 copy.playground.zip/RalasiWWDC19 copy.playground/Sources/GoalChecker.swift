import Foundation
import UIKit
import PlaygroundSupport

public class GoalChecker: UIView{
     var foodCon = UIImageView()
     var winCon = UIImageView()
    override public init(frame: CGRect) {
        super.init(frame: mainFrame)
   stepOne()
    self.backgroundColor = .white
    
    }
    
    
    
    func stepOne(){
    
        foodCon.ImageSimplified(named: "foodCon", contentMode: .scaleAspectFit, frame: CGRect(x:30, y:110, width: 200, height: 250), cornerRadius: 0)
    
        
        winCon.ImageSimplified(named: "award", contentMode: .scaleToFill, frame: CGRect(x: 600, y:40, width:200,height:250), cornerRadius: 0)
        
        self.addSubview(foodCon)
        self.addSubview(winCon)
        
        
    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
