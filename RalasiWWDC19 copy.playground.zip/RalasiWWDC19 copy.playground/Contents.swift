import UIKit
import PlaygroundSupport
var str = "Hello, WWDC"


//: # Solving World Problems
 
//:  Even in this modern world where Elon Musk is imagining the future of humanity on Mars, there are the fundamental problems *(like education, water problems, poverty, starvation)* which are not solved yet. SO, let's solve some in today's WWDC playground.
 
 
//:  ## Food security and malnutrition

//: Still about 18.2% people on the earth are hungry. The basic problems of world aren't solved. [1](https://www.inc.com/business-insider/worlds-top-10-problems-according-millennials-world-economic-forum-global-shapers-survey-2017.html)

//: Still today about **1/10** person goes to bed being hungry 😮
//:  Still, **800 million** people are hungry today. [2](https://www.youtube.com/watch?v=QJG7HmQyYcY)

//: Most of the world's population live in countries where overweight and obesity kills more people than underweight

//:[Source : WHO](https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight)
//: ![Man suffering with obesity](obe.png)

//: ![Childrens suffering with malnutrition](mal.jpeg)



//: ## How did we solved that in this program?

//: Here, we will solve that problem in a "Choose your adventure" 2D game.


//: But we bring **BIG CHANGES** by taking **SMALL STEPS**

//: **Step 1** : Save food in our daily life

//: **Step 2** : Reduce the demand of food in international market (and thus reduce the price of grains and vegetable in international market and *preventing the price rise*)


//: **Step 4** : Reward time


//: #### START SMALL, DO BIG




var view = SmallChanges(frame: mainFrame)
PlaygroundPage.current.liveView = view
