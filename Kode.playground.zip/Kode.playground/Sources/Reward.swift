import Foundation
import UIKit
import PlaygroundSupport


/*
 Aim of this class:
 -Reward the user for recusing the world
 -
 
 */
public class Reward : UIView{
    
    //declaring visual elements
    var bgIm = UIImageView()
    var image = UIImageView()
    var label = UILabel()
    var but = UIButton()
    var ans = UIView()
    var applewatch = UIButton()
    var headphones = UIButton()
    
    //a button to take you back
    var backB = UIButton()
    
    //the saying that i say
    var string1 = "Thanks for helping me rescue the world!"
    var string2 = "I give you two options for the reward"
    var string3 = "Which reward would you like to take?"
    
    var string4 = "Hurray! You have got an Apple Watch Series 3!! You are a real superman"
    
    var string5 = "Bravo! You have been claimed a BeatX headphone! Voila, you are a real spiderman"
    
    
    override public init(frame: CGRect) {
        super.init(frame:mainFrame)
        
        //calling important functions
        self.editingView()
        
        //adding Backbutton
        backB.BackButton()
        backB.addTarget(self, action: #selector(takesYouBack), for: .touchUpInside)
        self.addSubview(backB)
        
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(startSaying), userInfo: nil, repeats: false)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    
    @objc func startSaying(){
        self.addSubview(ans)
        ans.frame = CGRect(x:230,y:167,width: 370,height:190)
        ans.backgroundColor = .white
        ans.layer.cornerRadius = 8
        
        
        print("I have started to say")
        ans.addSubview(label)
        label.LabelSimplified(text: string1, size: 20, weight: .regular, frame: CGRect(x:12,y:10,width:334,height:145), alignment: .center)
        
        label.TypeWriter(typedText: string1, characterDelay: 1)
        
        Timer.scheduledTimer(timeInterval: 1.2, target: self, selector: #selector(addButton), userInfo: nil, repeats: false)
    }
    
    @objc func addButton(){
        
        but.buttonSimplified(color: .red, textColor: .white, text: "Next", frame: CGRect(x:245,y:403,width:293,height:80), textSize: 25)
        
        self.addSubview(but)
        
        but.addTarget(self, action: #selector(secondT), for: .touchUpInside)
    }
    
    @objc func reward(){
        label.LabelSimplified(text: string3, size: 15, weight: .light, frame: CGRect(x:10,y:10,width:334,height:140), alignment: .center)
        
        applewatch.buttonSimplified(color: .clear, textColor: .black, text: "⌚️", frame: CGRect(x:70,y:90,width:60,height:75), textSize: 45)
        
        headphones.buttonSimplified(color: .clear, textColor: .black, text: "🎧", frame: CGRect(x: 216, y: 90, width: 60, height: 75), textSize: 45)
        
        
        applewatch.addTarget(self, action: #selector(giftapplewatch), for: .touchUpInside)
        
        headphones.addTarget(self, action: #selector(giftheadphones), for: .touchUpInside)
        but.removeFromSuperview()
        ans.addSubview(applewatch)
        ans.addSubview(headphones)
    }
    
    @objc func giftapplewatch(){
        imp()
        label.TypeWriter(typedText: string4, characterDelay: 1)
        print("I will send you an Apple Watch via Amazon")
        
        
        but.addTarget(self, action: #selector(lastScene), for: .touchUpInside)
    }
    
    
    @objc func giftheadphones(){
        imp()
        label.TypeWriter(typedText: string5, characterDelay: 1)
        print("I will send you BeatX headphones via eBay")
        but.addTarget(self, action: #selector(lastScene), for: .touchUpInside)
    }
    @objc func secondT(){
        
        label.TypeWriter(typedText: string2, characterDelay: 1.2)
        but.addTarget(self, action: #selector(reward), for: .touchUpInside)
    }
    
    @objc func imp(){
        applewatch.removeFromSuperview()
        headphones.removeFromSuperview()
        self.addSubview(but)
    }
    
    func editingView(){
        
        bgIm.ImageSimplified(named: "milkyway.jpg", contentMode: .scaleAspectFit, frame: self.frame, cornerRadius: 0)
        
        image.ImageSimplified(named: "IMG_1236.png", contentMode: .scaleAspectFit, frame: CGRect(x:611, y:224, width:199,height:354), cornerRadius: 0)
        
        
        print("hello")
        
        
        self.addSubview(bgIm)
        self.addSubview(image)
    }
    
    
    @objc func lastScene(){
        self.removeFromSuperview()
        var lastScene = LastClass(frame: mainFrame)
        PlaygroundPage.current.liveView = lastScene
    }
    
    @objc func takesYouBack(){
        self.removeFromSuperview()
        var Menu = SmallChanges(frame: mainFrame)
        PlaygroundPage.current.liveView = Menu
    }
    
}

