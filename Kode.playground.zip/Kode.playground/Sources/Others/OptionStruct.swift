import Foundation
import UIKit
public struct option{
    
    var emojiString : String
    var optionString : String
    var color : UIColor
    init(emoji : String, option:String,color: UIColor) {
        self.emojiString = emoji
        self.optionString = option
        self.color = color
    }
}
