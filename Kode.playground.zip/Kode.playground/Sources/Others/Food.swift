 import Foundation
 import SpriteKit
 import GameKit
 
 
 //Food
 class Food
 {
    var food : String
    var score  : Int
    var lifetime : CGFloat
    
    init(food : String,score : Int,lifeTime: CGFloat)
    {
        self.food = food
        self.score = score
        self.lifetime = lifeTime
    }
    
    func getFood() -> String
    {
        return self.food
    }
    
    func getLifetime() -> CGFloat{
        return self.lifetime
    }
    
    func getMark() -> Int
    {
        return self.score
    }
    
 }
 
 
 class TouchSpriteNode : SKSpriteNode
 {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let fadeOutAction = SKAction.fadeOut(withDuration: 0.25)
        fadeOutAction.timingMode = .easeInEaseOut
        
        self.run(fadeOutAction, completion: {
            
            self.removeFromParent()
        })
        
    }
 }
 
 
 //Extending the Class SKLabelNode to set the touchAbleProperty of the Emoji
 
// protocol FoodNodeDelegate: class {
//    func didTap(sender: FoodNode)
// }
// 
// class FoodNode : SKLabelNode
// {
//    var delegate :FoodNodeDelegate!
//    
//    
//    
//   
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        
//        
//        if let delegate = delegate
//        {
//            delegate.didTap(sender: self)
//            return
//        }
//        let fadeOutAction = SKAction.fadeOut(withDuration: 0.05)
//        fadeOutAction.timingMode = .easeInEaseOut
//        self.run(fadeOutAction, completion: {
//            self.removeFromParent()
//        })
//        
//    }
// }
// 
// 
//
