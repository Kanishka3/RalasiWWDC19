
import SpriteKit
import PlaygroundSupport

import GameKit


public class ReduceWasteage : SKScene {
    
    
    // Game Timer and Score Label
    let roundIdentifier = "roundLabel"
    let timerIndentifier = "timerLabel"
    let scoreIdentifier = "scoreLabel"
    
    //array
    
    var bgImage = SKSpriteNode(imageNamed: "5.png")
    var Rules = SKLabelNode()
    var play = SKSpriteNode(imageNamed: "Play.png")
    
    //but
    var FoodNode = SKLabelNode()
    
    //other elements
    var isTimeOver = false
    var scoreValue = 0
    
    
    //other game element
    
    var timer : SKLabelNode = SKLabelNode()
    var mark : SKLabelNode = SKLabelNode()
    
    var GoodFood : [Food] = [Food]()
    
    public override func didMove(to view: SKView) {
        bgImage.position = CGPoint(x: frame.midX, y: frame.midY)
        bgImage.size = self.frame.size
        addChild(bgImage)
        
        ///formatting the label
        Rules = SKLabelNode(text: "Rules:  \n \n You got time of 35 seconds \n \n  \n You are  \n \n \n You get 10 points for fruits (eg. 🍎,🍌,🍓) \n \n \n  You get 5 points for junk food (eg.🍕,🍔,🌭) \n \n  You got 15 points for vegetable(eg.🍆,🥦,🥔) \n You get 20 points for cooked food (eg.🍳,🥐,🍡) ")
        Rules.fontName = "Chalkduster"
        Rules.fontSize = 22
        //just applying some simple logic
        Rules.position = CGPoint(x: 320, y:100)
        Rules.numberOfLines = 6
        Rules.name = "rules"
        addChild(Rules)
        addChild(play)
        
        
        //formatting button
        play.size = CGSize(width: 120, height: 30)
        play.position = CGPoint(x:415,y:54)
        
    }
    
    
    //  setting the stack of emojis
    
    func setStackyEmoji(){
        
        //junk food
        var food = Food(food: "🍕", score: 5, lifeTime: 3)
        GoodFood.append(food)
        
        food = Food(food: "🍩", score: 5, lifeTime: 3)
        GoodFood.append(food)
        
        food = Food(food: "🍔", score: 5, lifeTime: 3)
        GoodFood.append(food)
        
        food =  Food(food: "🍟", score: 5, lifeTime: 3)
        GoodFood.append(food)
        
        //fruits
        food = Food(food: "🍓", score: 10, lifeTime: 4)
        GoodFood.append(food)
        
        food = Food(food: "🍒", score: 10, lifeTime: 4)
        GoodFood.append(food)
        
        food = Food(food: "🍎", score: 10, lifeTime: 4)
        GoodFood.append(food)
        
        food = Food(food: "🍊", score: 10, lifeTime: 4)
        GoodFood.append(food)
        
        food = Food(food: "🍉", score: 10, lifeTime: 4)
        GoodFood.append(food)
        
        //vegetable
        food = Food(food:"🥦",score:15,lifeTime:5)
        GoodFood.append(food)
        
        food = Food(food:"🥒",score:15,lifeTime:5)
        GoodFood.append(food)
        
        food = Food(food:"🥕",score:15,lifeTime:5)
        GoodFood.append(food)
        
        food =  Food(food:"🥔",score:15,lifeTime:5)
        GoodFood.append(food)
        
        food =   Food(food:"🍅",score:15,lifeTime:5)
        GoodFood.append(food)
        
        //cooked food
        food = Food(food: "🌮", score: 20, lifeTime: 4)
        GoodFood.append(food)
        
        food =  Food(food: "🍜", score: 20, lifeTime: 4)
        GoodFood.append(food)
        
        food =  Food(food: "🍝", score: 20, lifeTime: 4)
        GoodFood.append(food)
        
        food =  Food(food: "🍛", score: 20, lifeTime: 4)
        GoodFood.append(food)
        
    }
    
    
    
    func otherChanges(){
        mark = SKLabelNode(fontNamed: "Noteworthy")
        mark.text = "Score : \(scoreValue)"
        
        print("things are constrained")
        //        game.zPosition = 0
//        mark.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: timer.frame.width * 1.25 , height: timer.frame.height * 2.5))
        mark.physicsBody?.isDynamic = false
        mark.fontSize = 20
        mark.fontColor = SKColor.black
        mark.position = CGPoint(x: 320, y:100)
        
        addChild(mark)
        
        
    }
    
    @objc func addEmojiOnRandomPlaces()
    {
        otherChanges()
        print("it is executed")
        let randomEmojiIndex = GKRandomSource.sharedRandom().nextInt(upperBound: GoodFood.count)
//
//        let randomEmojiPositionX = 10 +  GKRandomSource.sharedRandom().nextInt(upperBound: Int(self.frame.width - 20))
//        let randomEmojiPositionY = 50 + GKRandomSource.sharedRandom().nextInt(upperBound: Int(self.frame.height - 40))
//
        var width = self.frame.width
        var height = self.frame.height
        
let randomPosition = CGPoint(x:CGFloat(arc4random()).truncatingRemainder(dividingBy: height), y: CGFloat(arc4random()).truncatingRemainder(dividingBy: width))

        
        let emoji = FoodNode
        emoji.text = GoodFood[randomEmojiIndex].food
        emoji.isUserInteractionEnabled = true
        emoji.position = randomPosition
        
        let maxRadius = max(emoji.frame.size.width/2, emoji.frame.size.height/2)
        let interPersonSeparationConstant: CGFloat = 1.25
        emoji.physicsBody = SKPhysicsBody(circleOfRadius: maxRadius*interPersonSeparationConstant)
        
        emoji.physicsBody = SKPhysicsBody(circleOfRadius: maxRadius * interPersonSeparationConstant)
        let randomTime = GKRandomSource.sharedRandom().nextInt(upperBound: 4)
        let time = GoodFood[randomEmojiIndex].lifetime + CGFloat(randomTime)
        let fadeOutAction = SKAction.fadeOut(withDuration: TimeInterval(time)) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        emoji.run(fadeOutAction, completion: {
            print("the closure is executed")
            emoji.removeFromParent()
            self.addEmojiOnRandomPlaces()
        })
        
        
        addChild(emoji)
    }
    
    
    
    //addes emoji
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        
        guard let touch = touches.first else {
            return
        }
        let touchPosition = touch.location(in: self)
        let touchedNodes = nodes(at: touchPosition)
        for node in touchedNodes {
            if let nodeTouched = play as? SKSpriteNode {
                print("Come and fix")
                play.removeFromParent()
                Rules.removeFromParent()
                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(addEmojiOnRandomPlaces), userInfo: nil, repeats: false)
            }
        }
    }
    
    
    public    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        guard let touch = touches.first else{
            return
        }
        let pos = touch.location(in: self)
        var touchedN = nodes(at: pos)
        for node in touchedN {
            //            if let nodeTouches = FoodNode as? FoodNode {
            //        let fadeAway = SKAction.fadeOut(withDuration: 0.8)
            //        fadeAway.timingMode = SKActionTimingMode.easeOut
            //        ///to remove it when touched
            //        self.run(fadeAway) {
            //            self.removeFromParent()
            //        }
            //
            //        }
            
        }
        
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        for touch in touches {
            let location = touch.location(in: self)
        }
    }
}



//
//extension ReduceWasteage: FoodNodeDelegate{
//
//    //Handles when user clicks on the Emoji and adds an Animation.
//    func didTap(sender: FoodNode) {
//        let value = Int(sender.name ?? "0")
//        scoreValue = scoreValue + (value ?? 0)
//        self.mark.text = "Score : \(scoreValue)"
//
//        if value! > 0
//        {
//            let namaste = SKLabelNode(fontNamed: "Helvetica Neue")
//            namaste.text = "+\(value!)"
//
//            namaste.fontSize = 15
//            namaste.fontColor = SKColor.blue
//            namaste.position = CGPoint(x: sender.position.x, y: sender.position.y)
//            addChild(namaste)
//
//            var fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            namaste.run(fadeOutAction, completion: {
//                namaste.removeFromParent()
//            })
//
//            let starEmoji = "🌟"
//            let emoji1 = SKLabelNode(fontNamed: "Helvetica Neue")
//            emoji1.text = starEmoji
//            emoji1.fontSize = 20
//            emoji1.fontColor = SKColor.black
//            emoji1.position = CGPoint(x: sender.position.x + 20, y: sender.position.y)
//            addChild(emoji1)
//            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            emoji1.run(fadeOutAction, completion: {
//                emoji1.removeFromParent()
//            })
//
//            let emoji2 = SKLabelNode(fontNamed: "Helvetica Neue")
//            emoji2.text = starEmoji
//            emoji2.fontSize = 20
//            emoji2.fontColor = SKColor.black
//            emoji2.position = CGPoint(x: sender.position.x, y: sender.position.y + 20)
//            addChild(emoji2)
//            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            emoji2.run(fadeOutAction, completion: {
//                emoji2.removeFromParent()
//            })
//
//            let emoji3 = SKLabelNode(fontNamed: "Helvetica Neue")
//            emoji3.text = starEmoji
//
//            emoji3.fontSize = 20
//            emoji3.fontColor = SKColor.black
//            emoji3.position = CGPoint(x: sender.position.x - 20, y: sender.position.y)
//            addChild(emoji3)
//            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            emoji3.run(fadeOutAction, completion: {
//                emoji3.removeFromParent()
//            })
//
//        }
//        else if value! < 0
//        {
//            let namaste = SKLabelNode(fontNamed: "Helvetica Neue")
//            namaste.text = "\(value!)"
//            namaste.fontSize = 15
//            namaste.fontColor = SKColor.red
//            namaste.position = CGPoint(x: sender.position.x, y: sender.position.y)
//            addChild(namaste)
//
//
//            var fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            namaste.run(fadeOutAction, completion: {
//
//                namaste.removeFromParent()
//            })
//
//            let heatEmoji = "💥"
//
//            let emoji1 = SKLabelNode(fontNamed: "Helvetica Neue")
//            emoji1.text = heatEmoji
//            emoji1.fontSize = 20
//            emoji1.fontColor = SKColor.black
//            emoji1.position = CGPoint(x: sender.position.x + 20, y: sender.position.y)
//            addChild(emoji1)
//            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            emoji1.run(fadeOutAction, completion: {
//                emoji1.removeFromParent()
//            })
//
//            let emoji2 = SKLabelNode(fontNamed: "Helvetica Neue")
//            emoji2.text = heatEmoji
//            emoji2.fontSize = 20
//            emoji2.fontColor = SKColor.black
//            emoji2.position = CGPoint(x: sender.position.x, y: sender.position.y + 20)
//            addChild(emoji2)
//            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            emoji2.run(fadeOutAction, completion: {
//                emoji2.removeFromParent()
//            })
//
//            let emoji3 = SKLabelNode(fontNamed: "Helvetica Neue")
//            emoji3.text = heatEmoji
//            emoji3.fontSize = 20
//            emoji3.fontColor = SKColor.black
//            emoji3.position = CGPoint(x: sender.position.x - 20, y: sender.position.y)
//            addChild(emoji3)
//            fadeOutAction = SKAction.fadeOut(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
//            fadeOutAction.timingMode = .easeInEaseOut
//            emoji3.run(fadeOutAction, completion: {
//                emoji3.removeFromParent()
//            })
//
//        }
//
//        let fadeOutActions = SKAction.fadeOut(withDuration: 0.05)
//        fadeOutActions.timingMode = .easeInEaseOut
//        sender.run(fadeOutActions, completion: {
//            sender.removeFromParent()
//            self.addEmojiOnRandomPlaces()
//        })
//    }
//
//}
//
//
//
