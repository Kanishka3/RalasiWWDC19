import Foundation
import UIKit
import PlaygroundSupport



class ReducingInternationalDemand: UIView {
//declaring important at visual eleemnts
var backB = UIButton()

//blink text
var label1 = UILabel()
var label2 = UILabel()
var button = UIButton()

//visual elements
var option1V = UIButton()
var option2V = UIButton()
var option3V = UIButton()
var option4V = UIButton()


//other button stuff
var emojiL1 = UILabel()
var option1 = UILabel()

var emojiL2 = UILabel()
var option2 = UILabel()

var emojiL3 = UILabel()
var option3 = UILabel()

var emojiL4 = UILabel()
var option4 = UILabel()

//----------------------- Information String ---------------------- \\
var string1 = "There are seven questions each with four options. You have to choose one and try to make better decision. "

var string2 = "You can become a better consumer. Try to make better and better decision in every step"
// ------------------------- Q1 ---------------------------- \\

var ques1 = "Which bread would you like to buy? (in context of longitivity)"

//text of first options
var option11 = "Bread Expiring today"
var option12 = "Bread expiring after 2 days"
var option13 = "Bread which already expired"
var option14 = "Bread expiring after 4 days"

// ------------------------- Q2 ---------------------------- \\
var ques2 = "Which market is more preferable to buy grocery from?"

var option21 = "Local Store"
var option22 = "International Market"
var option23 = "Online Store"
var option24 = "Pick from garbage"

// ---------------------- Q3 ----------------------------- \\
var ques3 = "You throwed a party but some of the food was left. What you will do?"

var option31 = "Keep it as it is"
var option32 = "Throw one more party (LMAO)"
var option33 = "Give it to poor families living near you"
var option34 = "Throw it"

// ----------------------- Q4 ----------------------------- //

var ques4 = "How often will you buy your grocery?"

var option41 = "Buy it every year"
var option42 = "Buy every month"
var option43 = "Buy fortnightly"
var option44 = "Buy weekly"

// ----------------------- Q5 ----------------------------- //

var ques5 = "Where would you prefer to store some remaining food left during today's meal"

var option51 = "Keep it at normal temp."
var option52 = "Freez it"
var option53 = "Do nothing"
var option54 = "throw it into garbage"

// ----------------------- Q6 ----------------------------- //

var ques6 = "It's Saturday night! What would you like to do from following?"

var option61 = "Sleep Hungry"
var option62 = "Make instant noodles and eat it"
var option63 = "Order pizza"
var option64 = "Microwave and eat the rice you made yesterday"

// ----------------------- Q7 ----------------------------- //

var ques7 = "Where would you like to get some more information about food waste?"

var option71 = "Snapchat"
var option72 = "Instagram"
var option73 = "BBC Good Food"
var option74 = "Facebook"



// question stuff
var view = UIView()
var label = UILabel()

public override init(frame: CGRect){
    super.init(frame: mainFrame)
    /// fomatting the back button
    backB.BackButton()
    
    option1V.frame = CGRect(x: 55, y: 266, width: 300, height: 80)
    option2V.frame = CGRect(x: 437, y:266, width:300, height: 80)
    option3V.frame = CGRect(x: 55, y: 400, width: 300, height: 80)
    option4V.frame = CGRect(x:437, y: 400,width: 300,height:80)
    //        backB.addTarget(self, action: #selector(BackToMenu), for: .touchUpInside)
    self.backgroundColor = .white
    
    //formatting the options
    self.firstView()
    
    var allOptions : [UILabel] = [emojiL1, emojiL2, emojiL3, emojiL4]
    var allText : [UILabel] = [option1, option2,option3,option4]
    
    
    for i in allOptions {
        
        i.frame = CGRect(x:15,y:20,width:51, height:50)
        i.font = UIFont.systemFont(ofSize: 40, weight: .bold)
        i.textAlignment = NSTextAlignment.center
        
        
    }
    for i in allText{
        i.frame =  CGRect(x:50,y:15,width:180,height:70)
        i.textAlignment = NSTextAlignment.center
        i.font = UIFont.systemFont(ofSize: 20, weight: .regular)
        i.textColor = .white
        i.layer.cornerRadius = 12
        i.numberOfLines = -1
    }
    
    option1V.backgroundColor = .red
    option2V.backgroundColor = .blue
    option3V.backgroundColor = .green
    option4V.backgroundColor = .orange
    
    
    //        label.LabelSimplified(text: questionText, size: 40, weight: .regular, frame: CGRect(x:8,y:15,width:600, height:150), alignment: .center)
    label.layer.borderColor = UIColor.black.cgColor
    label.layer.cornerRadius = 30
    label.font = UIFont.systemFont(ofSize: 24, weight: .regular)
    label.frame = CGRect(x:90,y:56,width:645,height:165)
    view.addSubview(label)
}

@objc func firstView(){
    label1.BoldyMen(text: string1, size: 34)
    label1.frame = CGRect(x:71,y:20,width:668,height: 318)
    button.buttonSimplified(color: .red, textColor: .white, text: "Next >>", frame: CGRect(x: 484,y:486,width: 200,height:80), textSize: 18)
    
    
    self.addSubview(button)
    self.addSubview(label1)
    
    button.addTarget(self, action: #selector(changeLabel), for: .touchUpInside )
}

@objc func changeLabel(){
    label1.TypeWriter(typedText: string2)
    button.addTarget(self, action: #selector(TakeMeToQuizView), for: .touchUpInside)
}

@objc func TakeMeToQuizView(){
    
    option1V.addSubview(emojiL1)
    option1V.addSubview(option1)
    
    option2V.addSubview(emojiL2)
    option2V.addSubview(option2)
    
    
    option3V.addSubview(emojiL3)
    option3V.addSubview(option3)
    
    
    option4V.addSubview(emojiL4)
    option4V.addSubview(option4)
    
    
    option1.text = option11
    option2.text = option12
    option3.text = option13
    option4.text = option14
    
    
    emojiL1.text = "🍞"
    emojiL2.text = "🍞"
    emojiL3.text = "🍞"
    emojiL4.text = "🍞"
    
    
    
    label1.removeFromSuperview()
    button.removeFromSuperview()
    label.text = ques1
    
    self.addSubview(view)
    self.addSubview(option1V)
    self.addSubview(option2V)
    self.addSubview(option3V)
    self.addSubview(option4V)
    
    option1V.addTarget(self, action: #selector(quiz2), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(quiz2), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(quiz2), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(quiz2), for: .touchUpInside)
    
    
    
}

@objc func quiz2(){
    
    
    
    option1.text = option21
    option2.text = option22
    option3.text = option23
    option4.text = option24
    
    
    emojiL1.text = "👩🏼‍🌾"
    emojiL2.text = "👨🏼‍🌾"
    emojiL3.text = "🖥"
    emojiL4.text = "😲"
    
    label.text = ques2
    
    option1V.addTarget(self, action: #selector(quiz3), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(quiz3), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(quiz3), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(quiz3), for: .touchUpInside)
}

@objc func quiz3(){
    
    
    option1.text = option31
    option2.text = option32
    option3.text = option33
    option4.text = option34
    
    
    emojiL1.text = "🙅🏻‍♀️"
    emojiL2.text = "🎉"
    emojiL3.text = "🤚🏼"
    emojiL4.text = "🙈"
    label.text = ques3
    
    option1V.addTarget(self, action: #selector(quiz4), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(quiz4), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(quiz4), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(quiz4), for: .touchUpInside)
}

@objc func quiz4(){
    
    option1.text = option41
    option2.text = option42
    option3.text = option43
    option4.text = option44
    
    
    emojiL1.text = "📆"
    emojiL2.text = "🗓"
    emojiL3.text = "📅"
    emojiL4.text = "💹"
    
    label.text = ques4
    
    option1V.addTarget(self, action: #selector(quiz5), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(quiz5), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(quiz5), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(quiz5), for: .touchUpInside)
}

@objc func quiz5(){
    
    option1.text = option51
    option2.text = option52
    option3.text = option53
    option4.text = option54
    
    
    emojiL1.text = "☀️"
    emojiL2.text = "❄️"
    emojiL3.text = "🙅🏻‍♂️"
    emojiL4.text = "😲"
    label.text = ques5
    
    option1V.addTarget(self, action: #selector(quiz6), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(quiz6), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(quiz6), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(quiz6), for: .touchUpInside)
}

@objc func quiz6(){
    
    option1.text = option61
    option2.text = option62
    option3.text = option63
    option4.text = option64
    
    
    emojiL1.text = "😑"
    emojiL2.text = "🍜"
    emojiL3.text = "🍕"
    emojiL4.text = "🍚"
    label.text = ques6
    
    option1V.addTarget(self, action: #selector(quiz7), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(quiz7), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(quiz7), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(quiz7), for: .touchUpInside)
}


@objc func quiz7(){
    option1.text = option61
    option2.text = option62
    option3.text = option63
    option4.text = option64
    
    
    emojiL1.text = "🖼"
    emojiL2.text = "🤳🏼"
    emojiL3.text = "🌮"
    emojiL4.text = "👩🏼‍💻"
    label.text = ques7
    
    option1V.addTarget(self, action: #selector(final), for: .touchUpInside)
    option2V.addTarget(self, action: #selector(final), for: .touchUpInside)
    option3V.addTarget(self, action: #selector(final), for: .touchUpInside)
    option4V.addTarget(self, action: #selector(final), for: .touchUpInside)
}

@objc func final(){
    
    //removing all elements from the scene
    option1V.removeFromSuperview()
    option2V.removeFromSuperview()
    option3V.removeFromSuperview()
    option4V.removeFromSuperview()
    view.removeFromSuperview()
    label1.text = "You are get better and better at making every decision. Keep on going! Time to use your entreprenurial skills in starting an NGO"
    
    button.addTarget(self, action: #selector(GO2NGO), for: .touchUpInside)
    self.addSubview(button)
    self.addSubview(label1)
}


@objc func GO2NGO(){
    self.removeFromSuperview()
    var view = socialserver(frame:mainFrame)
    PlaygroundPage.current.liveView = view
}

required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
}


///Back to menu
@objc func BackToMenu(){
    self.removeFromSuperview()
    //        var view = SmallChanges(frame: mainFrame)
    PlaygroundPage.current.liveView = view
}

}
