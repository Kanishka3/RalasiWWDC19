import Foundation
import UIKit
import AVFoundation
import PlaygroundSupport

/*
 Aim of this class:
 1) Creating a UIAlertView like structure using UIView
 2) Add a notification sound
 3) Shake the UIAlertView
 
 */
public class wholeView: UIView{
    
    
    var alertView = UIView(frame: CGRect(x: 218, y: 156, width: 362, height: 227))
    
    //declaring visual elements
    var OKButton = UIButton()
    var player = AVAudioPlayer()
    
    public override init(frame: CGRect) {
        super.init(frame:mainFrame)
        
        // calling important functions
        
        self.AlertFunc()
        self.NotificationSound()
        
        //time to do some touchup
        self.addGradientLayer(colors: [UIColor.black.cgColor, UIColor.gray.cgColor, UIColor.black.cgColor])
        
        Timer.scheduledTimer(timeInterval: 1.4, target: self, selector:  #selector(shake), userInfo:nil, repeats: false)
        
        //playing the sound
        
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(NotificationSound), userInfo: nil, repeats: false)
        
    }
    @objc func shake(){
        alertView.shakeitoff(duration:4,repeatC:20,change:50)
        print("The program is being executed")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    ///Modifying the Alert View
    func AlertFunc(){
        
        var string1 = "Allow “WWDC19” access the world?"
        let string2 = "\n Let’s rescue the fundamental problems of world in this playground!"
        
        let font1 = UIFont.systemFont(ofSize: 20, weight: .heavy)
        let font2 = UIFont.systemFont(ofSize: 18, weight: .medium)
        
        let label = UILabel()
        
        //Using and formatting NSAttributedString
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font1,
            .foregroundColor: UIColor.black
        ]
        
        let attributedText = NSMutableAttributedString(string: string1, attributes: attributes)
        
        
        let toAppend = NSAttributedString(string: string2, attributes: [NSAttributedString.Key.font : font2])
        
        attributedText.append(toAppend)
        
        
        label.attributedText = attributedText
        label.numberOfLines = -1
        label.frame = CGRect(x: 10, y: 13, width: 352, height: 144)
        label.textAlignment = NSTextAlignment.center
        
        alertView.backgroundColor = .white
        alertView.addSubview(label)
        alertView.layer.cornerRadius = 20
        alertView.addSubview(OKButton)
        
        OKButton.setTitle("OK", for: .normal)
        OKButton.layer.borderColor = UIColor.black.cgColor
        OKButton.setTitleColor(UIColor.blue, for: .normal)
        OKButton.fortified(color: .black, size: 3)
        
        
        OKButton.frame = CGRect(x: 0, y: 171, width: 361, height: 56)
        OKButton.addTarget(self, action: #selector(nextView), for: .touchUpInside)
        
    }
    
    ///Uses CABAsicAnimation to the shake the Alert View
    @objc func shakinAnimation(){
        let midX = alertView.center.x
        let midY = alertView.center.y
        let animation = CABasicAnimation(keyPath: "shakeitoffliketaylorswift")
        
        
        animation.duration = 4
        animation.repeatCount = 30
        animation.autoreverses = true
        animation.fromValue = CGPoint(x: midX - 30, y: midY)
        animation.toValue = CGPoint(x: midX + 30, y: midY)
        
        alertView.layer.add(animation, forKey: "shakeitoffliketaylorswift")
        
        print("the field is being changed")
    }
    
    
    @objc func NotificationSound() {
        
        let path = Bundle.main.path(forResource: "notification", ofType : "mp3")!
        let url = URL(fileURLWithPath : path)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player.play()
            
        } catch {
            
            print ("There is an issue with this code!")
            
        }
        
        self.addSubview(alertView)
        
    }
    
    
    ///Help to take you to the next view
    @objc func nextView() {
        
        alertView.removeFromSuperview()
        PlaygroundPage.current.liveView =  BlinkText(frame: mainFrame)
        
    }
}


